function wp = prox_L2(wx,gamma)


wp = wx/(1+gamma);
